function [MUAmean,MUAstd,wrange] = epidermisMuaCompareEPOS(bodyLocation,skinType)
%EPOS plot OPs by Fitzskin types 
% close all;clear all;
clc
%this code will separate the optical properties between skin types
T = readtable('EPOS_demographics_n100.xlsx');
% type1="InnWrist";
% type2="OutWrist";
% type3="InnForearm"
% type = (type1 | type2);
%InnForearm
% type3="InnForearm";
% type = (type1 | type2 | type3);
type = bodyLocation;
Index1 = find(contains(T.filename,type));
T = T(Index1,:);
wrange = 523:741; %610
load Pilot222 %loading EPOS data
% Y = zeros(100,length(wrange));
WWW=8; %broadband average to compute I actually chose 550 +/- 10 indecies (not necessarily wavelengths)

for jj = 1:length(wrange)
xx=find(lambda==wrange(jj));% select wavelength to plot
MUAepi2 = (mean(muaEpi(Index1,xx-WWW:xx+WWW),2)*10); %(muaEpi(Index1,xx)*10) --> this is what is was ntot sure why Jessica didnt et the average for this  one so i added the average.
Y(jj,:) = MUAepi2;
clear MUAepi2
end
% for ii = 1:100
% figure(1);
% semilogy(wrange,Y(:,ii)), hold on
% end 
% hold off
% title(strcat("EPOS ",type) , 'n = 100')
% xlabel('wavelength [nm]', 'FontSize',12);
% ylabel('\mu_a_,_e_p_i [cm^-^1]', 'FontSize',12);
% ylim([0 60])
% if strcmp(type,"OutWrist") == 1
% sprintf('participant %d outerwrist absorption increases with wavelength',T.ID(80))
% end
%% extract certain skintypes
% for skinType = 1:6

Index1 = find((T.Fitzpatrick==skinType));
newTable = T(Index1,:);
MUAmean = mean(Y(:,Index1),2)';
MUAstd = std(Y(:,Index1),'',2)';
% figure; %validate that the shade function does the same thing
% plot(wrange,MUAmean), hold on
% plot(wrange,MUAmean+MUAstd,'r-'),
% plot(wrange,MUAmean-MUAstd,'r-'),
% hold off
% title(sprintf('Fitzpatrick Skin = %d',type))
% xlabel('wavelength [nm]', 'FontSize',12);
% ylabel('\mu_a_,_e_p_i [cm^-^1]', 'FontSize',12);
% ylim([0 100])
% cla
% amatrix = Y(:,Index1)';
% myColor = {'#F3E9DB','#FFEAC3','#ECD179','#D7A60A','#97754E','#6E3A0B'};
% figure(10); 
% stdshade(amatrix,.4,[hex2rgb(myColor{skinType})],wrange,''); hold on 
% nSkinType(skinType) = length(Index1);
% % end
% hold off
% % title(strcat("EPOS ",type) , 'n = 100'),
% xlabel('wavelength [nm]', 'FontSize',12);
% ylabel('\mu_a_,_e_p_i [cm^-^1]', 'FontSize',12);
% ylim([0 100])
% 
% legend('',sprintf('I, (n = %d)',nSkinType(1)),...
%     '',sprintf('II, (n = %d)',nSkinType(2)),...
%     '',sprintf('III, (n = %d)',nSkinType(3)),...
%     '',sprintf('IV, (n = %d)',nSkinType(4)),...
%     '',sprintf('V, (n = %d)',nSkinType(5)),...
%     '',sprintf('VI, (n = %d)',nSkinType(6)))
% ax = gca;
% ax.FontSize = 16;

%{ 
 stdshade(amatrix,alpha,acolor,F,smth)
- acolor defines the used color (default is red)
- F assignes the used x axis (default is steps of 1).
- alpha defines transparency of the shading (default is no shading and black mean line)
- smth defines the smoothing factor (default is no smooth)
%}
%%

end




