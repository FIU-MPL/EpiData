%%% Figures for Epidermis/Melanin Paper

clear,clc,close all
addpath(strcat(pwd,'\webPlot'));
addpath(strcat(pwd,'\PlotDigitizer'));


%%
%==============================Wan=========================================
Wan = load('Wan.csv');
figure(1)
set(gcf,'color','w','position',[277 134 1420 753])
plot(Wan(:,1),Wan(:,2),'r','LineWidth',1.5,"DisplayName",'Wan (from Mignon Review)') % from Mignon et al. Figure 1 A.
hold on
WanW = load('WanCaucasian.csv');
WanB = load('WanDarkBlack.csv');
plot(WanW(:,1),WanW(:,2),'ro','LineWidth',1.5,"DisplayName",'Wan Caucasian') % from Wan et al. Figure 5 A.
plot(WanB(:,1),WanB(:,2),'r*','LineWidth',1.5,"DisplayName",'Wan Black') % from Wan et al. Figure 5 B.
[maxval,maxidx] = (max(WanW(:,2)));
[minval,minidx] = (min(WanW(:,2)));
%inerpolate
fprintf('Wan Caucasian skin max is %3.1f [/cm] at %3.1f nm, min is %3.1f [/cm] at %3.1f nm \n',maxval, WanW(maxidx,1),minval,WanW(minidx,1))
[maxval,maxidx] = (max(WanB(:,2)));
[minval,minidx] = (min(WanB(:,2)));
fprintf('Wan dark black skin max is %3.1f [/cm] at %3.1f nm, min is %3.1f [/cm] at %3.1f nm \n',maxval, WanB(maxidx,1),minval,WanB(minidx,1))
L1 = 250:800;
newWanW = interp1(WanW(:,1),WanW(:,2),L1);
newWanB = interp1(WanB(:,1),WanB(:,2),L1);
[maxdiffval,maxdiffidx] = max(abs(newWanB-newWanW));
fprintf('highest absolute difference of %3.1f cm-1 noted at %3.1f nm \n', maxdiffval,L1(maxdiffidx))
%========================Marchesini========================================
Marchesini = load('Marchesini.csv'); % from Mignon et al. Figure 1A.
plot(Marchesini(:,1),Marchesini(:,2),'m','LineWidth',1.5,"DisplayName",'Marchesini (from Mignon Review)'),% from Mignon et al.

Marchesini_mean = load('Marchesini_mean.csv'); % from Marchesini et al. Figure 3A.
plot(Marchesini_mean(:,1),Marchesini_mean(:,2),'Color',[0.627 0.125 0.941],'LineWidth',1.5,"DisplayName",'Marchesini (1992)'),% from Marchesini et al. Figure 3 A.

Marchesini_upper = load('Marchesini_upper.csv'); % from Marchesini et al. Figure 3A.
Marchesini_lower = load('Marchesini_lower.csv'); % from Marchesini et al. Figure 3A.

[maxval,maxidx] = (max(Marchesini_upper(:,2)));
[minval,minidx] = (min(Marchesini_lower(:,2)));
fprintf('Marchesini Caucasian skin max is %3.3f [/cm] at %3.1f nm, min is %3.4f [/cm] at %3.1f nm \n',...
    maxval, Marchesini_upper(maxidx,1),minval,Marchesini_lower(minidx,1))
% 62.7% red, 12.5% green and 94.1% blue
%=======================Salomatina=========================================
Salomatina = load('Salomatina.csv'); % from Mignon et al. Figure 1A.
plot(Salomatina(:,1),Salomatina(:,2),'g','LineWidth',1.5,"DisplayName",'Salomatina (from Mignon Review)'),% from Mignon et al.

Salomatina_mua7_mean = load('Salomatina_mua7_mean.csv');% from Salomatina et al.Fig 2.A
plot(Salomatina_mua7_mean(:,1),Salomatina_mua7_mean(:,2)*10,'Color',[0 200/256 0],'LineWidth',1.5,"DisplayName",'Salomatina (2007)'),% from Salomatina et al.Fig 2.A

Salomatina_mua7_upper = load('Salomatina_mua7_upper.csv'); % from Salomatina et al.Fig 2.A
Salomatina_mua7_lower = load('Salomatina_mua7_lower.csv'); %from Salomatina et al.Fig 2.A

[maxval,maxidx] = (max(Salomatina_mua7_upper(:,2)*10));
[minval,minidx] = (min(Salomatina_mua7_lower(:,2)*10));
fprintf('Salomatina Caucasian skin max is %3.3f [/cm] at %3.1f nm, min is %3.4f [/cm] at %3.1f nm \n',...
    maxval, Salomatina_mua7_upper(maxidx,1),minval,Salomatina_mua7_lower(minidx,1))

%===========================Shimojo========================================

Shimojo = load('Shimojo_abs_mean.csv'); % from Shimojo et al.
plot(Shimojo(:,1),Shimojo(:,2)*10,'b','LineWidth',1.5,"DisplayName",'Shimojo Skin Type III-IV')  %convert from mm^-1 to cm^-1

Shimojo_abs_upper = load('Shimojo_abs_upper.csv'); % from Shimojo et al.Fig 2.A
Shimojo_abs_lower = load('Shimojo_abs_lower.csv'); %from Shimojo et al.Fig 2.A

[maxval,maxidx] = (max(Shimojo_abs_upper(:,2)*10));
[minval,minidx] = (min(Shimojo_abs_lower(:,2)*10));
fprintf('Shimojo Asian skin (Type III-IV) max is %3.3f [/cm] at %3.1f nm, min is %3.4f [/cm] at %3.1f nm \n',...
    maxval, Shimojo_abs_upper(maxidx,1),minval,Shimojo_abs_lower(minidx,1))

%0% red, 50.2% green and 50.2% blue.



% Models
%==============================Saager======================================
Saager = load('Rolf_melanin.csv'); % from Saager et al. reports values in mm
plot(Saager(:,1),Saager(:,2)*10,'k--','LineWidth',1.5,"DisplayName",'Saager Skin Type III') 
[maxval,maxidx] = (max(Saager(:,2)*10));
[minval,minidx] = (min(Saager(:,2)*10));

fprintf('Saager Skin Type III max is %3.3f [/cm] at %3.1f nm, min is %3.4f [/cm] at %3.1f nm \n',...
maxval, Saager(maxidx,1),minval,Saager(minidx,1))

%===================Shimojo(Jacques)=======================================
% add Jacques model - Jacques African Skin, plot digitized from Shimojo et al. 
JacquesAfrican = load('JacquesAfrican_from_Shimojo.csv'); % from Saager et al.
plot(JacquesAfrican(:,1),JacquesAfrican(:,2)*10,'--','Color',[0 .502 .502],'LineWidth',1.5,"DisplayName",'African, Jacques Model (Shimojo et al 2020)') 
[maxval,maxidx] = (max(JacquesAfrican(:,2)*10));
[minval,minidx] = (min(JacquesAfrican(:,2)*10));

fprintf('Jacques African Skin max is %3.3f [/cm] at %3.1f nm, min is %3.4f [/cm] at %3.1f nm \n',...
maxval, JacquesAfrican(maxidx,1),minval,JacquesAfrican(minidx,1))
%==========================Jacques=========================================
%  Jacques model - From Jacques review paper (2011) origially Tseng 2011 (incorect reference, actually 2009!)
lambda = 300:1000;
muamel=(519)*(lambda/500).^-3; %absorption of a melanosome [3 10 16 23 32 42] skin types I-VI, Ajmal et al. 2021
% percentages of volume fracton from Tseng 2009
fv2 = 2;% •	for light skinned caucasions, fv = 1-3% mean 2%
fv4 = 13.5;% •	for well-tanned caucasions and Mediterraneans, fv = 11-16% mean 13.5%
fv6 = 31; % •	for darkly pigmented Africans, fv = 18-43%. mean 31%
%Epidermal absortion acccording to melanosome concentration, excluding other chromophores
muaMelanosomeX2 = muamel*fv2/100 ;%
muaMelanosomeX4 = muamel*fv4/100 ;%
muaMelanosomeX6 = muamel*fv6/100 ;%

plot(lambda,muaMelanosomeX2,'--','Color',[0 .700 .300],'LineWidth',1.5,"DisplayName",'Caucasian (2%), Jacques Model (Jacques 2013 and Tseng 2009)')
plot(lambda,muaMelanosomeX4,'--','Color',[.700 .300 0],'LineWidth',1.5,"DisplayName",'Mediterraneans (13.5%), Jacques Model(Jacques 2013 and Tseng 2009)')
plot(lambda,muaMelanosomeX6,'--','Color',[.700 0 .300],'LineWidth',1.5,"DisplayName",'Africans (31%), Jacques Model (Jacques 2013 and Tseng 2009)')


%================================Jonasson==================================
% Hanna Jonasson, Ingemar Fredriksson, Sara Bergstrand, Carl Johan Östgren, Marcus Larsson, Tomas Strömberg
upperP = 0.48 + 0.36; % percentages reported by Hanna Jonansson 
lowerP = 0.48 - 0.36;
% Total amount of melanin to concentration milli Molar? (mm?)
upperC = upperP/100;
lowerC = lowerP/100;
% micorns to millimiemeter
thickness = 100/1000; %epidermal thickness from micrometer to millimeter
% he total amount of melanin (melanin concentration times epidermis thickness) was on average 
melConc =upperC/ thickness;
lambda = 300:1000;
muaMelanosome=(519)*(lambda/500).^-3;
muaEpidermis1 = muaMelanosome * melConc ;
plot(lambda,muaEpidermis1,'--','Color',[0.6 .230 .500],'LineWidth',1.5,"DisplayName",'Caucasian darker(8.4%), (Jonasson 2018)')
melConc =lowerC/ thickness;
muaMelanosome=(519)*(lambda/500).^-3;
muaEpidermis2 = muaMelanosome * melConc ;
plot(lambda,muaEpidermis2,'--','Color',[.600 0.8 .900],'LineWidth',1.5,"DisplayName",'Caucasian lighter(1.2%), (Jonasson 2018)')


%=============================Meglinski====================================
Meglinski = load('Meglinski2002mua.csv');%mm-1
plot(Meglinski(:,1),10*Meglinski(:,2),'--','Color',[0.6 .230 .500],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Meglinski 2002 and Lister 2012)')
%=============================Patwardhan==================================
PatwardHig = load('Patward2005muaHigMel.csv'); %mm-1
PatwardMid = load('Patward2005muaMidMel.csv');
PatwardLow = load('Patward2005muaLowMel.csv');
plot(PatwardLow(:,1),10*PatwardLow(:,2),'--','Color',[0.6 .230 .000],'LineWidth',1.5,"DisplayName",'Light Pigment, (Patwardhan 2005)')
plot(PatwardMid(:,1),10*PatwardMid(:,2),'--','Color',[0.6 .230 .500],'LineWidth',1.5,"DisplayName",'Medium Pigment, (Patwardhan 2005)')
plot(PatwardHig(:,1),10*PatwardHig(:,2),'--','Color',[0.6 .230 1],'LineWidth',1.5,"DisplayName",'High Pigment, (Patwardhan 2005)')
%=============================Rodriguez===================================
Rodriguez = load('Rodriguez2022.csv');
plot(Rodriguez(:,1),Rodriguez(:,2),'--','Color',[.1 .230 .700],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Rodriguez 2022)')
%=============================Svaasand====================================
Svaa = load('Svaasand1995mua.csv'); %mm-1
plot(Svaa(:,1),10*Svaa(:,2),'--','Color',[.3 .10 .00],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Svaasand 1995)')
%=============================Tsui=========================================
TsuiDarm = load('Tsui2018Darmmua.csv');
TsuiFace = load('Tsui2018Facemua.csv');
TsuiVarm = load('Tsui2018Varmmua.csv');
plot(TsuiDarm(:,1),TsuiDarm(:,2),'--','Color',[.9 .0 .500],'LineWidth',1.5,"DisplayName",'Dorsal Arm (17.2%), (Tsui 2018)')
plot(TsuiVarm(:,1),TsuiVarm(:,2),'--','Color',[.9 .50 .500],'LineWidth',1.5,"DisplayName",'Ventral Arm (11.3%), (Tsui 2018)')
plot(TsuiFace(:,1),TsuiFace(:,2),'--','Color',[.9 1 .500],'LineWidth',1.5,"DisplayName",'Face (8.23%), (Tsui 2018)')


%==========Figure Labels======================================
hold off
legend('Wan','Wan Caucasian','Wan Black','Marchesini','Salomatina','Shimojo','Saager')
% legend("show",Location="best");
title('Epidermis Absorption Coefficient')
xint1 = 300;
xint2 = 1000;
xlim([xint1 xint2])
xlabel('wavelength [nm]')
ylabel('absorption coefficient, \mu_a [cm^-^1]', 'FontSize',16);
ax = gca;
ax.FontSize = 16;


%%
%=========================================================================
%============================LOG SCALE===================================
%=========================================================================
%    Mua plot for paper is this one

figure(2)
% set(gcf,'color','w')%,'position',[826 131 2396 1207])
clf
set(gcf,'color','w','position',[277 134 1420 753])

%============= combine skin type bands
lambda = 300:1000;
muamel=(519)*(lambda/500).^-3; %absorption of a melanosome [3 10 16 23 32 42] skin types I-VI, Ajmal et al. 2021
myColor = {'#FFEAC3','#D7A60A','#6E3A0B'};
mua_m = 1.7*10^12.*lambda.^-3.48;
mua_m2 = 1.7*10^12.*lambda.^-3.15;
melc = [0.3 1.5 7 7 12 17 17 3 4]./100;
mua_L(1,:) = melc(1)*mua_m;
mua_L(2,:) = melc(2)*mua_m;
mua_L(3,:) = melc(3)*mua_m;
mua_M(1,:) = melc(4)*mua_m;
mua_M(2,:) = melc(5)*mua_m;
mua_M(3,:) = melc(6)*mua_m;
mua_D(1,:) = melc(7)*mua_m;
mua_D(2,:) = melc(8)*mua_m2;
mua_D(3,:) = melc(9)*mua_m2;
hold on
% clf
set(gcf,'color','w')
set(gcf,'color','w','position',[277 134 1420 753])
% stdshade(R2,0.5,[hex2rgb(myColor(1))],l3)
% hold on

% stdshade(mua_L,0.5,[hex2rgb(myColor(1))],lambda);
l5 = [lambda, fliplr(lambda)];
btw1 = [mua_L(1,:), fliplr(mua_L(3,:))];
h=fill(l5, btw1, [hex2rgb(myColor(1))],"DisplayName",'light pigmentation (I-II)');
hold off
set(h,'edgecolor',[hex2rgb(myColor(1))]);
alpha(0.5);
hold on

% stdshade(mua_M,0.5,[hex2rgb(myColor(2))],lambda);
btw2 = [mua_M(1,:), fliplr(mua_M(3,:))];
h2=fill(l5, btw2, [hex2rgb(myColor(2))],"DisplayName",'medium pigmentation (III-IV)');
hold off
set(h2,'edgecolor',[hex2rgb(myColor(2))]);
alpha(0.5);
hold on

% stdshade(mua_D,0.5,[hex2rgb(myColor(3))],lambda);
btw3 = [mua_D(1,:), fliplr(mua_D(3,:))];
h3=fill(l5, btw3, [hex2rgb(myColor(3))],"DisplayName",'dark pigmentation (V-IV)');
hold off
set(h3,'edgecolor',[hex2rgb(myColor(3))]);
alpha(0.5);
hold on
% semilogy(Saager(:,1),Saager(:,2)*10/.01,'--','color',[hex2rgb(myColor(2))],'LineWidth',1.5,"DisplayName",'Skin Type III, Saager et al (2015)')


% plot paper data

%======== experimental
% semilogy(Wan(:,1),Wan(:,2),'r','LineWidth',1.5,"DisplayName",'Wan (from Mignon Review)'), hold on % from Mignon et al.
semilogy(WanB(:,1),WanB(:,2),'r','LineWidth',2,"DisplayName",'Black, Wan et al (1981), Fiber'),hold on  % from Wan et al. Figure 5 B.
% from Shimojo et al.
semilogy(Shimojo(:,1),Shimojo(:,2)*10,'b','LineWidth',2,"DisplayName",'Skin Type III-IV, Shimojo et al (2020), Fiber')  %convert from mm^-1 to cm^-1
semilogy(WanW(:,1),WanW(:,2),'k','LineWidth',2,"DisplayName",'Caucasian, Wan et al (1981), Fiber'),  % from Wan et al. Figure 5 A.
% semilogy(Marchesini(:,1),Marchesini(:,2),'m','LineWidth',1.5,"DisplayName",'Marchesini (from Mignon Review)'),% from Mignon et al.
% semilogy(Salomatina(:,1),Salomatina(:,2),'g','LineWidth',1.5,"DisplayName",'Salomatina (from Mignon Review)'),% from Mignon et al.
semilogy(Marchesini_mean(:,1),Marchesini_mean(:,2),'Color',[0.627 0.125 0.941],'LineWidth',2,"DisplayName",'Caucasian, Marchesini et al (1992), Fiber'),% from Marchesini et al. Figure 3 A.
semilogy(Salomatina_mua7_mean(:,1),Salomatina_mua7_mean(:,2)*10,'Color',[0 200/256 0],'LineWidth',2,"DisplayName",'Caucasian, Salomatina et al (2006), Confocal'),% from Mignon et al.
% from Saager et al.  ---- divide by 0.01 to scale epidermal thickness from
% paper states is volume scaled value
semilogy(Saager(:,1),Saager(:,2)*10/0.01,'c-','LineWidth',1.5,"DisplayName",'Skin Type III, Saager et al (2015), SFDI/S')

Jon2023mean = load('Jona2023meanmuatepi_mm.csv');
semilogy(Jon2023mean(:,1),Jon2023mean(:,2).*10./0.063,'Color',[.85 .3 .1],'LineWidth',1.5,"DisplayName",'Caucasian, Jonasson et al (2023), Fiber')
% Jon2023min = load('Jona2023minnmuatepi_mm.csv');
% semilogy(Jon2023mean(:,1),Jon2023mean(:,2).*10./0.063,'m-^','LineWidth',1.5,"DisplayName",'Caucasian, Jonasson et al (2023), Fiber')
% Jon2023max = load('Jona2023maxmuatepi_mm.csv');
% semilogy(Jon2023mean(:,1),Jon2023mean(:,2).*10./0.063,'m-o','LineWidth',1.5,"DisplayName",'Caucasian, Jonasson et al (2023), Fiber')


% % EPOS DATA %=========================================================================
% myColor = {'#F3E9DB','#FFEAC3','#ECD179','#D7A60A','#97754E','#6E3A0B'};
% bodyLocation = ["InnWrist","OutWrist","InnForearm"];
% skinType = 1:6;
% for gg = 1:6
% [MUAmean,MUAstd,wrange]= epidermisMuaCompareEPOS(bodyLocation{1},skinType(gg));
% % from Rodriguez et al.
% semilogy(wrange,MUAmean,'LineWidth',1.5,"DisplayName",sprintf('EPOS %s Type %d (MPL)',bodyLocation{1},gg))
% end

%======= models
% % % % % lambda = 300:1000;
% % % % % muamel=(519)*(lambda/500).^-3; %absorption of a melanosome [3 10 16 23 32 42] skin types I-VI, Ajmal et al. 2021
% % % % % 
% % % % % %=== dark skin
% % % % % % Jacques model - Jacques African Skin, plot digitized from Shimojo et al. 
% % % % % semilogy(PatwardHig(:,1),10*PatwardHig(:,2),'--','Color',[0.6 .230 1],'LineWidth',1.5,"DisplayName",'High Pigment, (Patwardhan 2005)')
% % % % % 
% % % % % 
% % % % % %  Jacques model - From Jacques review paper (2011) origially Tseng 2011 (incorect reference, actually 2009!)
% % % % % 
% % % % % % •	for darkly pigmented Africans, fv = 18-43%. mean 31%
% % % % % semilogy(lambda,muaMelanosomeX6,'--','Color',[.700 0 .300],'LineWidth',1.5,"DisplayName",'Africans (31%), Jacques Model (Jacques 2013 and Tseng 2009)')
% % % % % semilogy(JacquesAfrican(:,1),JacquesAfrican(:,2)*10,'--','Color',[0 .502 .502],'LineWidth',1.5,"DisplayName",'African, Jacques Model (Shimojo et al 2020)'),
% % % % % 
% % % % % %=== medium skin
% % % % % % •	for well-tanned caucasions and Mediterraneans, fv = 11-16% mean 13.5%
% % % % % semilogy(lambda,muaMelanosomeX4,'--','Color',[.700 .300 0],'LineWidth',1.5,"DisplayName",'Mediterraneans (13.5%), Jacques Model(Jacques 2013 and Tseng 2009)')
% % % % % semilogy(PatwardMid(:,1),10*PatwardMid(:,2),'--','Color',[0.6 .230 .500],'LineWidth',1.5,"DisplayName",'Medium Pigment, (Patwardhan 2005)')
% % % % % % Tsui
% % % % % semilogy(TsuiDarm(:,1),TsuiDarm(:,2),'--','Color',[.9 .0 .500],'LineWidth',1.5,"DisplayName",'Dorsal Arm (17.2%), (Tsui 2018)')
% % % % % semilogy(TsuiVarm(:,1),TsuiVarm(:,2),'--','Color',[.9 .50 .500],'LineWidth',1.5,"DisplayName",'Ventral Arm (11.3%), (Tsui 2018)')
% % % % % semilogy(TsuiFace(:,1),TsuiFace(:,2),'--','Color',[.9 1 .500],'LineWidth',1.5,"DisplayName",'Face (8.23%), (Tsui 2018)')
% % % % % 
% % % % % 
% % % % % %=== light skin
% % % % % semilogy(lambda,muaEpidermis1,'--','Color',[0.6 .230 .500],'LineWidth',1.5,"DisplayName",'Caucasian darker(8.4%), (Jonasson et al 2018)')
% % % % % semilogy(lambda,muaEpidermis2,'--','Color',[.6 0.8 .900],'LineWidth',1.5,"DisplayName",'Caucasian lighter(1.2%), (Jonasson et al 2018)')
% % % % % % •	for light skinned caucasions, fv = 1-3% mean 2%
% % % % % semilogy(lambda,muaMelanosomeX2,'--','Color',[0 .700 .300],'LineWidth',1.5,"DisplayName",'Caucasian (2%), Jacques Model (Jacques 2013 and Tseng 2009)')
% % % % % 
% % % % % % Meglinski
% % % % % semilogy(Meglinski(:,1),10*smooth(Meglinski(:,2)),'--','Color',[0.6 .00 .500],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Meglinski 2002 and Lister 2012)')
% % % % % % Svaasand
% % % % % semilogy(Svaa(:,1),10*Svaa(:,2),'--','Color',[.3 .10 .00],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Svaasand 1995 and Lister 2012)')
% % % % % % Patwardhan
% % % % % semilogy(PatwardLow(:,1),10*PatwardLow(:,2),'--','Color',[0.6 .230 .000],'LineWidth',1.5,"DisplayName",'Light Pigment, (Patwardhan 2005)')
% % % % % % Rodriguez
% % % % % semilogy(Rodriguez(:,1),Rodriguez(:,2),'--','Color',[.1 .230 .700],'LineWidth',1.5,"DisplayName",'Caucasian (1.3%), (Rodriguez 2022)')


% hold off
% legend('Wan','Wan Caucasian','Wan Black','Marchesini','Salomatina','Shimojo','Saager')

% plotting a square on the highest and lowest bounds
% txt = {'▣'};
% text(530,newWanB(L1==530),txt) %highest values is Wan's White
%  Find max ands min poitns at 530 interpolate black skin (Wan) and Saager () and draw a square at 530 nm
% newWanB(L1==530)
L2 = 450:980;
newSaager = interp1(Saager(:,1),Saager(:,2),L2);
% text(530,newSaager(L2==530)*10,txt) %highest values is Wan's White
ax = gca;
ax.FontSize = 16;

xint1 = 300;
xint2 = 1000;
set(gca,'YScale','log')
% ylabel('\mu_a [cm^-^1]');
% xlabel('Wavelength[nm]');
% xlim([xint1 xint2])
ylim([0.01 2000])
% legend('light pigmentation (I-II)','medium pigmentation (III-IV)','dark pigmentation (V-IV)')
lgd = legend("show",Location="best");
xlim([xint1 xint2])
% ldg.Location = 'best'
title('Epidermis Absorption Coefficient')
xlabel('Wavelength [nm]')
ylabel('absorption coefficient, \mu_a [cm^-^1]');
set(gca,'LineWidth',1,'FontSize',12); % for paper body
set(lgd,'fontsize',12);
box on

%% 
figure(21)
clf
set(gcf,'color','w')
set(gcf,'color','w','position',[277 134 1420 753])

%  Jacques model - From Jacques review paper (2011) origially Tseng 2011 (incorect reference, actually 2009!)
lambda = 300:1000;
muamel=(519)*(lambda/500).^-3; %absorption of a melanosome [3 10 16 23 32 42] skin types I-VI, Ajmal et al. 2021
myColor = {'#FFEAC3','#D7A60A','#6E3A0B'};
mua_m = 1.7*10^12.*lambda.^-3.48;
mua_m2 = 1.7*10^12.*lambda.^-3.15;
melc = [0.3 1.5 7 7 12 17 17 3 4]./100;
mua_L(1,:) = melc(1)*mua_m;
mua_L(2,:) = melc(2)*mua_m;
mua_L(3,:) = melc(3)*mua_m;
mua_M(1,:) = melc(4)*mua_m;
mua_M(2,:) = melc(5)*mua_m;
mua_M(3,:) = melc(6)*mua_m;
mua_D(1,:) = melc(7)*mua_m;
mua_D(2,:) = melc(8)*mua_m2;
mua_D(3,:) = melc(9)*mua_m2;

%============= experiemntal models
%====== light pigmentation
% •	for light skinned caucasions, fv = 1-3% mean 2%
% semilogy(lambda,muaMelanosomeX2,'-','Color',[hex2rgb(myColor(1))],'LineWidth',1.5,"DisplayName",'Caucasian (2%), Jacques Model (Jacques 2013 and Tseng 2009)')
% hold on
%top band
semilogy(lambda,muaEpidermis1,'-o','Color',[hex2rgb(myColor(1))],'LineWidth',1.5,"DisplayName",'Caucasian darker(8.4%), (Jonasson et al 2018)')
hold on
% semilogy(lambda,muaEpidermis2,'-','Color',[hex2rgb(myColor(1))],'LineWidth',1.5,"DisplayName",'Caucasian lighter(1.2%), (Jonasson et al 2018)')
% Meglinski
%bottom band
semilogy(Meglinski(:,1),10*smooth(Meglinski(:,2),1),'-^','Color',[hex2rgb(myColor(1))],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Meglinski 2002 and Lister 2012)')
% Svaasand
% semilogy(Svaa(:,1),10*Svaa(:,2),'-','Color',[hex2rgb(myColor(1))],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Svaasand 1995 and Lister 2012)')
% Patwardhan
% semilogy(PatwardLow(:,1),10*PatwardLow(:,2),'-','Color',[hex2rgb(myColor(1))],'LineWidth',1.5,"DisplayName",'Light Pigment, (Patwardhan 2005)')
% Rodriguez - middle band
semilogy(Rodriguez(:,1),Rodriguez(:,2),'-','Color',[hex2rgb(myColor(1))],'LineWidth',1.5,"DisplayName",'Caucasian (1.3%), (Rodriguez 2022)')

% stdshade(mua_L,0.5,[hex2rgb(myColor(1))],lambda);

%====== medium pigmentation
% •	for well-tanned caucasions and Mediterraneans, fv = 11-16% mean 13.5%
% semilogy(lambda,muaMelanosomeX4,'-','Color',[hex2rgb(myColor(2))],'LineWidth',1.5,"DisplayName",'Mediterraneans (13.5%), Jacques Model(Jacques 2013 and Tseng 2009)')

% from Saager et al. - outlier divide by 0.01 (thickness of 100um for
% thickness compensation
semilogy(Saager(:,1),Saager(:,2)*10/0.01,'--','color',[hex2rgb(myColor(2))],'LineWidth',1.5,"DisplayName",'Skin Type III, Saager et al (2015)')

% semilogy(PatwardMid(:,1),10*PatwardMid(:,2),'--','Color',[hex2rgb(myColor(2))],'LineWidth',1.5,"DisplayName",'Medium Pigment, (Patwardhan 2005)')
% Tsui - topband
semilogy(TsuiDarm(:,1),TsuiDarm(:,2),'-o','Color',[hex2rgb(myColor(2))],'LineWidth',1.5,"DisplayName",'Dorsal Arm (17.2%), (Tsui 2018)')
% semilogy(TsuiVarm(:,1),TsuiVarm(:,2),'--','Color',[hex2rgb(myColor(2))],'LineWidth',1.5,"DisplayName",'Ventral Arm (11.3%), (Tsui 2018)')
% bottom bad
semilogy(TsuiFace(:,1),TsuiFace(:,2),'-^','Color',[hex2rgb(myColor(2))],'LineWidth',1.5,"DisplayName",'Face (8.23%), (Tsui 2018)')

% stdshade(mua_L,0.5,[hex2rgb(myColor(1))],lambda);

%====== dark pigmentation
% Jacques model - Jacques African Skin, plot digitized from Shimojo et al. 
% bottom band
semilogy(JacquesAfrican(:,1),JacquesAfrican(:,2)*10,'-^','Color',[hex2rgb(myColor(3))],'LineWidth',1.5,"DisplayName",'African, Jacques Model (Shimojo et al 2020)'),
% •	for darkly pigmented Africans, fv = 18-43%. mean 31%
semilogy(lambda,muaMelanosomeX6,'-','Color',[hex2rgb(myColor(3))],'LineWidth',1.5,"DisplayName",'Africans (31%), Jacques Model (Jacques 2013 and Tseng 2009)')
% top band
semilogy(PatwardHig(:,1),10*PatwardHig(:,2),'-o','Color',[hex2rgb(myColor(3))],'LineWidth',1.5,"DisplayName",'High Pigment, (Patwardhan 2005)')

% stdshade(mua_L,0.5,[hex2rgb(myColor(1))],lambda);


% plot(lambda,0.19*mua_m,'b')


ylabel('\mu_a [cm^-^1]');
xlabel('Wavelength[nm]');
xint1 = 300;
xint2 = 1000;
xlim([xint1 xint2])
ylim([0.01 2000])
set(gca,'LineWidth',1,'FontSize',16); % for paper body


%============= mua bands from experimental model 3 skin zones
mua_m = 1.7*10^12.*lambda.^-3.48;
% l2 = lambda;
% RL = interp1(Rodriguez(:,1),Rodriguez(:,2),l2);
% RLmin = interp1(Meglinski(:,1),10*Meglinski(:,2),l2);
% RLmax = muaEpidermis1;
% R2(1,:)=RLmin(2:length(l2)-1);
% R2(2,:)=RL(2:length(l2)-1);
% R2(3,:)=RLmax(2:length(l2)-1);
% l3 = l2(2:length(l2)-1);


figure(22)
% hold on
clf
set(gcf,'color','w')
set(gcf,'color','w','position',[277 134 1420 753])
% stdshade(R2,0.5,[hex2rgb(myColor(1))],l3)
% hold on

% stdshade(mua_L,0.5,[hex2rgb(myColor(1))],lambda);
l5 = [lambda, fliplr(lambda)];
btw1 = [mua_L(1,:), fliplr(mua_L(3,:))];
h=fill(l5, btw1, [hex2rgb(myColor(1))]);
hold off
set(h,'edgecolor',[hex2rgb(myColor(1))]);
alpha(0.5);
hold on

% stdshade(mua_M,0.5,[hex2rgb(myColor(2))],lambda);
btw2 = [mua_M(1,:), fliplr(mua_M(3,:))];
h2=fill(l5, btw2, [hex2rgb(myColor(2))]);
hold off
set(h2,'edgecolor',[hex2rgb(myColor(2))]);
alpha(0.5);
hold on

% stdshade(mua_D,0.5,[hex2rgb(myColor(3))],lambda);
btw3 = [mua_D(1,:), fliplr(mua_D(3,:))];
h3=fill(l5, btw3, [hex2rgb(myColor(3))]);
hold off
set(h3,'edgecolor',[hex2rgb(myColor(3))]);
box on
alpha(0.5);
hold on
% semilogy(Saager(:,1),Saager(:,2)*10/.01,'--','color',[hex2rgb(myColor(2))],'LineWidth',1.5,"DisplayName",'Skin Type III, Saager et al (2015)')



set(gca,'YScale','log')
set(gca,'LineWidth',1,'FontSize',12); % for paper body
ylabel('\mu_a [cm^-^1]');
xlabel('Wavelength[nm]');
xlim([xint1 xint2])
ylim([0.01 2000])
legend('light pigmentation (I-II)','medium pigmentation (III-IV)','dark pigmentation (V-IV)')



%% experimental only
figure (3)
clf
% set(gcf,'color','w')%,'position',[826 131 2396 1207])
set(gcf,'color','w','position',[277 134 1420 753])

% SaloMinMua = load('SalomoMinMUA.csv');
% SaloMeanMua = load('SalomoMeanMUA.csv');
% SaloMaxMua = load('SalomoMaxMUA.csv');
% l2 = 400:2:1100;
% RR = interp1(SaloMeanMua(:,1),SaloMeanMua(:,2),l2);
% RRmin = interp1(SaloMinMua(:,1),SaloMinMua(:,2),l2);
% RRmax = interp1(SaloMaxMua(:,1),SaloMaxMua(:,2),l2);
% R2(1,:)=RRmin(2:350);
% R2(2,:)=RR(2:350);
% R2(3,:)=RRmax(2:350);
% l3 = l2(2:350);


% semilogy(Wan(:,1),Wan(:,2),'r','LineWidth',1.5,"DisplayName",'Wan (from Mignon Review)'), hold on % from Mignon et al.
semilogy(WanB(:,1),WanB(:,2),'r','LineWidth',1.5,"DisplayName",'Black, Wan et al (1981)'),hold on  % from Wan et al. Figure 5 B.
semilogy(WanW(:,1),WanW(:,2),'LineWidth',1.5,"DisplayName",'Caucasian, Wan et al (1981)'),  % from Wan et al. Figure 5 A.
% semilogy(Marchesini(:,1),Marchesini(:,2),'m','LineWidth',1.5,"DisplayName",'Marchesini (from Mignon Review)'),% from Mignon et al.
% semilogy(Salomatina(:,1),Salomatina(:,2),'g','LineWidth',1.5,"DisplayName",'Salomatina (from Mignon Review)'),% from Mignon et al.
semilogy(Marchesini_mean(:,1),Marchesini_mean(:,2),'Color',[0.627 0.125 0.941],'LineWidth',1.5,"DisplayName",'Caucasian, Marchesini et al (1992)'),% from Marchesini et al. Figure 3 A.
semilogy(Salomatina_mua7_mean(:,1),Salomatina_mua7_mean(:,2)*10,'Color',[0 200/256 0],'LineWidth',1.5,"DisplayName",'Caucasian, Salomatina et al (2006)'),% from Mignon et al.
% from Shimojo et al.
semilogy(Shimojo(:,1),Shimojo(:,2)*10,'b','LineWidth',1.5,"DisplayName",'Skin Type III-IV, Shimojo et al (2020)');hold on  %convert from mm^-1 to cm^-1

% figure
% stdshade(10*R2,0.5,[hex2rgb('#F3E9DB')],l3);


hold off

% legend('Wan','Wan Caucasian','Wan Black','Marchesini','Salomatina','Shimojo','Saager')
lgd = legend("show",Location="best");
xlim([xint1 xint2])
ylim([.01 1000])
% ldg.Location = 'best'
title('Epidermis Absorption Coefficient Experimental Studies')
xlabel('wavelength [nm]')
ylabel('absorption coefficient, \mu_a [cm^-^1]', 'FontSize',16);
% plotting a square on the highest and lowest bounds
txt = {'▣'};
% text(530,newWanB(L1==530),txt) %highest values is Wan's White
%  Find max ands min poitns at 530 interpolate black skin (Wan) and Saager () and draw a square at 530 nm
% newWanB(L1==530)
L2 = 450:980;
newSaager = interp1(Saager(:,1),Saager(:,2),L2);
% text(530,newSaager(L2==530)*10,txt) %highest values is Wan's White
ax = gca;
ax.FontSize = 16;

%% models only
figure (4)
clf
% set(gcf,'color','w')%,'position',[826 131 2396 1207])
set(gcf,'color','w','position',[277 134 1420 753])


% Jacques model - Jacques African Skin, plot digitized from Shimojo et al. 
semilogy(JacquesAfrican(:,1),JacquesAfrican(:,2)*10,'--','Color',[0 .502 .502],'LineWidth',1.5,"DisplayName",'African, Jacques Model (Shimojo et al 2020)')
hold on

%  Jacques model - From Jacques review paper (2011/2013) origially Tseng 2011 (incorect reference, actually 2009!)
lambda = 300:1000;
muamel=(519)*(lambda/500).^-3; %absorption of a melanosome [3 10 16 23 32 42] skin types I-VI, Ajmal et al. 2021

% •	for light skinned caucasions, fv = 1-3% mean 2%
semilogy(lambda,muaMelanosomeX2,'--','Color',[0 .700 .300],'LineWidth',1.5,"DisplayName",'Caucasian (2%), Jacques Model (Jacques 2013 and Tseng 2009)')
% •	for well-tanned caucasions and Mediterraneans, fv = 11-16% mean 13.5%
semilogy(lambda,muaMelanosomeX4,'--','Color',[.700 .300 0],'LineWidth',1.5,"DisplayName",'Mediterraneans (13.5%), Jacques Model(Jacques 2013 and Tseng 2009)')
% •	for darkly pigmented Africans, fv = 18-43%. mean 31%
semilogy(lambda,muaMelanosomeX6,'--','Color',[.700 0 .300],'LineWidth',1.5,"DisplayName",'Africans (31%), Jacques Model (Jacques 2013 and Tseng 2009)')
semilogy(lambda,muaEpidermis1,'--','Color',[0.6 .230 .500],'LineWidth',1.5,"DisplayName",'Caucasian darker(8.4%), (Jonasson et al 2018)')
semilogy(lambda,muaEpidermis2,'--','Color',[.6 0.8 .900],'LineWidth',1.5,"DisplayName",'Caucasian lighter(1.2%), (Jonasson et al 2018)')
% from Saager et al.
semilogy(Saager(:,1),Saager(:,2)*10/.01,'k--','LineWidth',1.5,"DisplayName",'Skin Type III, Saager et al (2015)')
% Meglinski
semilogy(Meglinski(:,1),10*smooth(Meglinski(:,2)),'--','Color',[0.6 .00 .500],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Meglinski 2002 and Lister 2012)')
% Svaasand
semilogy(Svaa(:,1),10*Svaa(:,2),'--','Color',[.3 .10 .00],'LineWidth',1.5,"DisplayName",'Caucasian (3%), (Svaasand 1995 and Lister 2012)')
% Patwardhan
semilogy(PatwardLow(:,1),smooth(10*PatwardLow(:,2)),'--','Color',[0.6 .230 .000],'LineWidth',1.5,"DisplayName",'Light Pigment, (Patwardhan 2005)')
semilogy(PatwardMid(:,1),10*PatwardMid(:,2),'--','Color',[0.6 .230 .500],'LineWidth',1.5,"DisplayName",'Medium Pigment, (Patwardhan 2005)')
semilogy(PatwardHig(:,1),10*PatwardHig(:,2),'--','Color',[0.6 .230 1],'LineWidth',1.5,"DisplayName",'High Pigment, (Patwardhan 2005)')
% Rodriguez
semilogy(Rodriguez(:,1),Rodriguez(:,2),'--','Color',[.1 .230 .700],'LineWidth',1.5,"DisplayName",'Caucasian (1.3%), (Rodriguez 2022)')
% Tsui
semilogy(TsuiDarm(:,1),TsuiDarm(:,2),'--','Color',[.9 .0 .500],'LineWidth',1.5,"DisplayName",'Dorsal Arm (17.2%), (Tsui 2018)')
semilogy(TsuiVarm(:,1),TsuiVarm(:,2),'--','Color',[.9 .50 .500],'LineWidth',1.5,"DisplayName",'Ventral Arm (11.3%), (Tsui 2018)')
semilogy(TsuiFace(:,1),TsuiFace(:,2),'--','Color',[.9 1 .500],'LineWidth',1.5,"DisplayName",'Face (8.23%), (Tsui 2018)')

hold off
% legend('Wan','Wan Caucasian','Wan Black','Marchesini','Salomatina','Shimojo','Saager')
lgd = legend("show",Location="best");
xlim([xint1 xint2])
ylim([.01 1000])

% ldg.Location = 'best'
title('Epidermis Absorption Coefficient Models')
xlabel('wavelength [nm]')
ylabel('absorption coefficient, \mu_a [cm^-^1]', 'FontSize',16);
% plotting a square on the highest and lowest bounds
txt = {'▣'};
% text(530,newWanB(L1==530),txt) %highest values is Wan's White
%  Find max ands min poitns at 530 interpolate black skin (Wan) and Saager () and draw a square at 530 nm
% newWanB(L1==530)
% L2 = 450:980;
% newSaager = interp1(Saager(:,1),Saager(:,2),L2);
% text(530,newSaager(L2==530)*10,txt) %highest values is Wan's White
ax = gca;
ax.FontSize = 16;
set(lgd,'fontsize',8);






%% mus

figure(5)
clf
set(gcf,'color','w','position',[277 134 1420 753])

%=== bands
musp_R = (2*10^12).*lambda.^-4;
musp_M = (2*10^5).*lambda.^-1.5;
musp_mel = musp_R + musp_M;
% plot(lambda,musp_mel)

% musp_b = 

myColor = {'#FFEAC3','#D7A60A','#6E3A0B'};
musp_b1 = 1.7*10^4.*lambda.^-0.7;
musp_b2 = 10^6.*lambda.^-1.3;
musp_b3 = 10^8.*lambda.^-1.95;

melc = [6 15 16 16 35 26 26 50 40]./100;
mus_L(1,:) = melc(1)*musp_b1;
mus_L(2,:) = melc(2)*musp_b1;
mus_L(3,:) = melc(3)*musp_b1;
mus_M(1,:) = melc(4)*musp_b1;
mus_M(2,:) = melc(5)*musp_b1;
mus_M(3,:) = melc(6)*musp_b2;
mus_D(1,:) = melc(7)*musp_b2;
mus_D(2,:) = melc(8)*mua_m;
mus_D(3,:) = melc(9)*musp_b3;


hold on
% plot(lambda,musp_mel)

% figure(22)
% % hold on
% % clf
% set(gcf,'color','w')
% set(gcf,'color','w','position',[277 134 1420 753])
% stdshade(R2,0.5,[hex2rgb(myColor(1))],l3)
% hold on

% stdshade(mua_L,0.5,[hex2rgb(myColor(1))],lambda);
l5 = [lambda, fliplr(lambda)];
btw1 = [mus_L(1,:), fliplr(mus_L(3,:))];
h=fill(l5, btw1, [hex2rgb(myColor(1))],"DisplayName",'light pigmentation (I-II)');
hold off
set(h,'edgecolor',[hex2rgb(myColor(1))]);
alpha(0.5);
hold on

% stdshade(mua_M,0.5,[hex2rgb(myColor(2))],lambda);
btw2 = [mus_M(1,:), fliplr(mus_M(3,:))];
h2=fill(l5, btw2, [hex2rgb(myColor(2))],"DisplayName",'medium pigmentation (III-IV)');
hold off
set(h2,'edgecolor',[hex2rgb(myColor(2))]);
alpha(0.5);
hold on

% stdshade(mua_D,0.5,[hex2rgb(myColor(3))],lambda);
btw3 = [mus_D(1,:), fliplr(mus_D(3,:))];
h3=fill(l5, btw3, [hex2rgb(myColor(3))],"DisplayName",'dark pigmentation (V-VI)');
hold off
set(h3,'edgecolor',[hex2rgb(myColor(3))]);

alpha(0.5);
hold on


%==== data

Jonnasmaxmusp = load('Jonnas2018maxmus.csv'); %mm-1
Jonnasmeanmusp = load('Jonnas2018meanmus.csv');
Jonnasminmusp = load('Jonnas2018minmus.csv');
%mus = musp/(1-g);
Patwardmus = load('Patward2005mus.csv'); %mm-1
RodLmusp = load('Rodriguez2022lowmusp.csv');
RodUmusp = load('Rodriguez2022higmusp.csv');
TsuiDarmmus = load('Tsui2018Darmmus.csv');
TsuiVarmmus = load('Tsui2018Varmmus.csv'); 
TsuiFacemus = load('Tsui2018Facemus.csv'); 
WanCau = load('Wan1981musCac.csv'); % msp 
WanDar = load('Wan1981musDar.csv');
ShimAs = load('Shimojo2020musp.csv'); %msp mm-1
March = load('Marc1992musp.csv'); %msp cm-1
Saag = load('Saager2015musp.csv'); %msp mm-1
Salo = load('SalomoMusp.csv'); %mm-1 msp

%==== dark
% % semilogy(Patwardmus(:,1),10*0.2*Patwardmus(:,2),'--','Color',[.5 1 .300],'LineWidth',1.5,"DisplayName",'Patwardhan (2005)*');

semilogy(WanDar(:,1),WanDar(:,2),'r-','LineWidth',1.5,"DisplayName",'Wan (Dark) (1981)');
%==== medium
% % semilogy(TsuiDarmmus(:,1),0.2*TsuiDarmmus(:,2),'--','Color',[.9 .0 .500],'LineWidth',1.5,"DisplayName",'Tsui Dorsal Arm (17.2%)(2018)*');
% % semilogy(TsuiVarmmus(:,1),0.2*TsuiVarmmus(:,2),'--','Color',[.9 .50 .500],'LineWidth',1.5,"DisplayName",'Tsui Ventral Arm (11.3%)(2018)*');
% % semilogy(TsuiFacemus(:,1),0.2*TsuiFacemus(:,2),'--','Color',[.9 .7 .500],'LineWidth',1.5,"DisplayName",'Tsui Face (8.23%) (2018)*');

semilogy(WanCau(:,1),WanCau(:,2),'k-','LineWidth',1.5,"DisplayName",'Wan (Caucasian) (1981)');
semilogy(ShimAs(:,1),10*ShimAs(:,2),'b-','LineWidth',2,"DisplayName",'Shimojo (Asian) (2020)');
% semilogy(Saag(:,1),10*Saag(:,2),'c-','LineWidth',1.5,"DisplayName",'Saager (Type III) (2015)');
%==== light
% semilogy(Jonnasmaxmusp(:,1),10*Jonnasmaxmusp(:,2),'-','Color',[.85 .3 .1 .5],'LineWidth',2,"DisplayName",'Caucasian (8.4%), Jonasson (2018)'); hold on;
% semilogy(Jonnasmeanmusp(:,1),10*Jonnasmeanmusp(:,2),'-','Color',[.85 .3 .1],'LineWidth',2,"DisplayName",'Caucasian (4.8%), Jonasson (2018)');
% semilogy(Jonnasminmusp(:,1),10*Jonnasminmusp(:,2),'-','Color',[.85 .3 .1 .5],'LineWidth',2,"DisplayName",'Caucasian (1.2%), Jonasson (2018)');

% % semilogy(RodLmusp(:,1),RodLmusp(:,2),'--','Color',[.1 .230 .700],'LineWidth',1.5,"DisplayName",'Rodriguez lower bound (2022)');
% % semilogy(RodUmusp(:,1),RodUmusp(:,2),'--','Color',[.1 .230 1],'LineWidth',1.5,"DisplayName",'Rodriguez upper bound (2022)');

semilogy(March(:,1),March(:,2),'-','Color',[0.627 0.125 0.941],'LineWidth',2,"DisplayName",'Marchesini (Caucasian) (1992)');
semilogy(Salo(:,1),10*Salo(:,2),'-','Color',[0 200/256 0],'LineWidth',2,"DisplayName",'Caucasian, Salomatina et al (2006)')

% hold off
% legend('Wan','Wan Caucasian','Wan Black','Marchesini','Salomatina','Shimojo','Saager')

box on
set(gca,'YScale','log')
set(gca,'LineWidth',1,'FontSize',12); % for paper body
% ylabel('\mu_a [cm^-^1]');
xlim([xint1 xint2])
ylim([4 600])
% legend('light pigmentation (I-II)','medium pigmentation (III-IV)','dark pigmentation (V-IV)')
lgd = legend("show",Location="best");
set(lgd,'fontsize',10);
xlim([xint1 xint2])
ylim([7 700])

% ldg.Location = 'best'
title('Epidermis Reduce Scattering Coefficient')
xlabel('wavelength [nm]')
ylabel('reduced scattering coefficient, \mu_s'' [cm^-^1]', 'FontSize',16);
% plotting a square on the highest and lowest bounds
txt = {'▣'};
% text(530,newWanB(L1==530),txt) %highest values is Wan's White
%  Find max ands min poitns at 530 interpolate black skin (Wan) and Saager () and draw a square at 530 nm
% newWanB(L1==530)
% L2 = 450:980;
% newSaager = interp1(Saager(:,1),Saager(:,2),L2);
% text(530,newSaager(L2==530)*10,txt) %highest values is Wan's White
ax = gca;
ax.FontSize = 12;
% fontsize(lgd,14,'points')


%% abs and rscat bands
figure(60)
clf
set(gcf,'color','w')
% scat
subplot(1,2,1)
l5 = [lambda, fliplr(lambda)];
btw1 = [mua_L(1,:), fliplr(mua_L(3,:))];
h=fill(l5, btw1, [hex2rgb(myColor(1))],"DisplayName",'light pigmentation (FST I-II)');
hold off
set(h,'edgecolor',[hex2rgb(myColor(1))]);
alpha(0.5);
hold on

% stdshade(mua_M,0.5,[hex2rgb(myColor(2))],lambda);
btw2 = [mua_M(1,:), fliplr(mua_M(3,:))];
h2=fill(l5, btw2, [hex2rgb(myColor(2))],"DisplayName",'medium pigmentation (FST III-IV)');
hold off
set(h2,'edgecolor',[hex2rgb(myColor(2))]);
alpha(0.5);
hold on

% stdshade(mua_D,0.5,[hex2rgb(myColor(3))],lambda);
btw3 = [mua_D(1,:), fliplr(mua_D(3,:))];
h3=fill(l5, btw3, [hex2rgb(myColor(3))],"DisplayName",'dark pigmentation (FST V-IV)');
hold off
set(h3,'edgecolor',[hex2rgb(myColor(3))]);
alpha(0.5);
hold on
ax = gca;
ax.FontSize = 16;

xint1 = 300;
xint2 = 1000;
set(gca,'YScale','log')
% ylabel('\mu_a [cm^-^1]');
% xlabel('Wavelength[nm]');
% xlim([xint1 xint2])
ylim([0.1 2000])
% legend('light pigmentation (I-II)','medium pigmentation (III-IV)','dark pigmentation (V-IV)')
lgd = legend("show",Location="best");
set(lgd,'fontsize',10);
xlim([xint1 xint2])
% ldg.Location = 'best'
title('Epidermis Absorption Coefficient')
xlabel('Wavelength [nm]')
ylabel('absorption coefficient, \mu_a [cm^-^1]');
set(gca,'LineWidth',1,'FontSize',12); % for paper body
% set(lgd,'fontsize',12);
box on
ylim([0.1 1100])



subplot(1,2,2)
    l5 = [lambda, fliplr(lambda)];
btw1 = [mus_L(1,:), fliplr(mus_L(3,:))];
h=fill(l5, btw1, [hex2rgb(myColor(1))],"DisplayName",'light pigmentation (FST I-II)');
hold off
set(h,'edgecolor',[hex2rgb(myColor(1))]);
alpha(0.5);
hold on

% stdshade(mua_M,0.5,[hex2rgb(myColor(2))],lambda);
btw2 = [mus_M(1,:), fliplr(mus_M(3,:))];
h2=fill(l5, btw2, [hex2rgb(myColor(2))],"DisplayName",'medium pigmentation (FST III-IV)');
hold off
set(h2,'edgecolor',[hex2rgb(myColor(2))]);
alpha(0.5);
hold on

% stdshade(mua_D,0.5,[hex2rgb(myColor(3))],lambda);
btw3 = [mus_D(1,:), fliplr(mus_D(3,:))];
h3=fill(l5, btw3, [hex2rgb(myColor(3))],"DisplayName",'dark pigmentation (FST V-VI)');
hold off
set(h3,'edgecolor',[hex2rgb(myColor(3))]);

alpha(0.5);
hold on

box on
set(gca,'YScale','log')
set(gca,'LineWidth',1,'FontSize',12); % for paper body
% ylabel('\mu_a [cm^-^1]');
xlim([xint1 xint2])
ylim([4 600])
% legend('light pigmentation (I-II)','medium pigmentation (III-IV)','dark pigmentation (V-IV)')
lgd = legend("show",Location="best");
set(lgd,'fontsize',10);
xlim([xint1 xint2])
ylim([7 700])

% ldg.Location = 'best'
title('Epidermis Reduce Scattering Coefficient')
xlabel('Wavelength [nm]')
ylabel('reduced scattering coefficient, \mu_s'' [cm^-^1]', 'FontSize',16);
% plotting a square on the highest and lowest bounds
txt = {'▣'};
% text(530,newWanB(L1==530),txt) %highest values is Wan's White
%  Find max ands min poitns at 530 interpolate black skin (Wan) and Saager () and draw a square at 530 nm
% newWanB(L1==530)
% L2 = 450:980;
% newSaager = interp1(Saager(:,1),Saager(:,2),L2);
% text(530,newSaager(L2==530)*10,txt) %highest values is Wan's White
ax = gca;
ax.FontSize = 12;
ylim([0.1 1100])


%%


%%

rmpath(strcat(pwd,'\webPlot'));
rmpath(strcat(pwd,'\PlotDigitizer'));






